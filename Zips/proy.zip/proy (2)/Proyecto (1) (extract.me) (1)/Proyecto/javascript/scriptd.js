
function mostrarSaludo() {
    const usuario = localStorage.getItem('usuario');
    if (usuario) {
        if (usuario === 'admin') {
            document.getElementById('saludo').innerText = '¡Bienvenido, Administrador!';
        } else {
            document.getElementById('saludo').innerText = `¡Bienvenido, ${usuario}!`;
        }
    } else {
        document.getElementById('saludo').innerText = '¡Bienvenido a Galaxarc!';
    }
}

// Mostrar saludo al cargar
window.onload = function () {
    mostrarSaludo();
};