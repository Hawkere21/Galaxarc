import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js'

    
    import { getAuth, signInWithEmailAndPassword} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js'
   

    const firebaseConfig = {
    apiKey: "AIzaSyCRw5jZZPvmdA3TgP_jRnuUHp_Y92to9Ew",
    authDomain: "anim-ai-13c1d.firebaseapp.com",
    databaseURL: "https://anim-ai-13c1d-default-rtdb.firebaseio.com",
    projectId: "anim-ai-13c1d",
    storageBucket: "anim-ai-13c1d.appspot.com",
    messagingSenderId: "508533010561",
    appId: "1:508533010561:web:3600df94f907b6be7bdd80",
    measurementId: "G-KMK4THVYBZ"
  };
  

  const init = initializeApp(firebaseConfig);

  const authI = getAuth(init);


  
const username = document.getElementById("username");
const password = document.getElementById("password");



document.getElementById('loginForm').addEventListener('submit', function (event) {
            event.preventDefault();
            const username = document.getElementById('username').value;
            signInWithEmailAndPassword(authI,username.value,password.value).then((userCredential) => {
            showModal("Inicio exitoso");                 
            localStorage.setItem('usuario', username);
            window.location.href = 'pagp.html';
            });
            
        });

function showModal(message) {
    document.getElementById('modalBody').textContent = message; // Insertar mensaje en el modal
    $('#notificationModal').modal('show'); // Mostrar el modal
    setTimeout(() => {
        $('#notificationModal').modal('hide'); // Cerrar el modal después de 3 segundos
    }, 3000);
};