document.getElementById('registroForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Validar longitud de contraseña (esto ya lo maneja HTML5)
    if (password.length < 6) {
        showModal('La contraseña debe tener al menos 6 caracteres.');
        return;
    }

    // Guardar en localStorage
    localStorage.setItem('registeredUsername', username);
    localStorage.setItem('registeredPassword', password);

    showModal('Registro exitoso, ya puedes iniciar sesión.');
    setTimeout(() => {
        window.location.href = 'login.html'; // Redirigir al inicio de sesión
    }, 3000); // Esperar 3 segundos antes de redirigir
});

function showModal(message) {
    document.getElementById('modalBody').textContent = message; // Insertar mensaje en el modal
    $('#notificationModal').modal('show'); // Mostrar el modal
    setTimeout(() => {
        $('#notificationModal').modal('hide'); // Cerrar el modal después de 3 segundos
    }, 3000);
}